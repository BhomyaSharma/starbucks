import React from 'react'

const Store = () => {
  return (
    <div>Store</div>
  )
}

export default Store