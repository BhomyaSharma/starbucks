import React from 'react'

const Rewards = () => {
  return (
    <div>Rewards</div>
  )
}

export default Rewards