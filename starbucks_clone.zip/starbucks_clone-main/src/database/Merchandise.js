export const Merchandise = [
    {
        id:"m-1" , 
    title : "Valentine Heart Mug - 355 ml",
desc : "Express your love with every sip using the Valentine Heart M...",
price : "1300",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114792.jpg"  
  },

  {
    id:"m-2" , 
title : "MUG RESTING DRAGON 473ml",
desc : "Resting dragon and their keeper are nestled on a ceramic mug....",
price : "1700",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114615_1.png"
  } ,
  {
    id:"m-3" , 
title : "Rabbit Holiday Mug - 89 ml",
desc : "Get into the holiday spirit with our Rabbit-themed mug, perfect for sipping your favorite drinks in style..",
price : "2200",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114469.jpg"
  } ,
  {
    id:"m-4" , 
title : "Pink Facet Cat Ceramic Mug 295 ml ",
desc : "Fall in love this Valentine's Day with this limited edition ..",
price : "2700",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114611.jpg"
  } ,
  {
    id:"m-5" , 
title : "MUGGIFT: Little Holiday Present -89 ml",
desc : "Discover the joy of a little holiday surprise with our MUGGI...",
price : "950",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114402.jpg"
  },
  {
    id:"m-6" , 
title : "MUG SS DUSTY ROSE 414ml",
desc : "Double walled with debossed siren logo in an elegant dusty r..",
price : "1950",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114610_1.png"
  } ,
  {
    id:"m-7" , 
title : "MUG SUMMER SAND 414ml",
desc : "Inspired by the scenery of the beachside, Hand paint glossy ...",
price : "1900",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/115214.jpg"
  }
,
{
  id:"m-8" , 
title : "Minnie Mouse Ceramic Mug - 355ml",
desc : "Minnie Mouse mug with a character's silhouette, dipped in gl..",
price : "2550",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114248.jpg"
}
,{
  id:"m-9" , 
title : "Fox & Cupcake Mug -295 ml",
desc : "Sip your favorite beverages in style with our Fox & Cupcake ...",
price : "2650",
image :"https://starbucksstatic.cognizantorderserv.com/Items/Small/114470.jpg"

}
]